import 'package:dash/dash.dart';

part 'provider.g.dart';

//@BlocProvider.register(BlocToRegister)
abstract class Provider {}