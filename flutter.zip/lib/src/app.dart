import 'package:flutter/material.dart';

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jiri',
      onGenerateRoute: route,
      theme: ThemeData(
          fontFamily: 'Roboto',
          brightness: Brightness.dark,
          primaryColor: Colors.lightGreen,
          accentColor: Colors.lightGreenAccent),
      debugShowCheckedModeBanner: false,
    );
  }

// Define routes
  Route route(_) {
    return MaterialPageRoute(builder: (BuildContext context) {
      return Container();
    });
  }
}
