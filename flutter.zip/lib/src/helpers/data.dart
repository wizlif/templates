import 'dart:convert';

class DataHelper {
  static Map<String,dynamic> toMap(data) {
    if (data != null) {
      if (data is String) {
        try {
          return json.decode(data);
        } catch (_) {
          return <String,dynamic>{};
        }
      } else if (data is Map) {
        return data;
      }
      return <String,dynamic>{};
    }

    return {};
  }
}
